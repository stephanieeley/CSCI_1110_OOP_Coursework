//Steph Eley
//5/20/2020
public interface Colorable {

	public abstract void howToColor();


}
